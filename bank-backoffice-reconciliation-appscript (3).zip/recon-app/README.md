# Bank & Back-Office Reconciliation — Apps Script Web App

A standalone Google Apps Script web application for reconciling **bank
statement exports** against **back-office / platform transaction exports**
across any number of payment channels (banks, e-wallets, payment
processors — e.g. UB Online, GCash, Maya, DragonPay, or anything else you
add).

It was inspired by a manual multi-tab spreadsheet reconciliation workbook
(separate tabs per bank/channel, manually eyeballing amounts and dates) and
rebuilds that workflow as a proper data-driven app: configurable channels,
a reusable column-mapping importer (every bank/platform exports different
columns), an automatic matching engine, an exceptions queue for manual
review, and a live dashboard.

## Features

- **Multi-channel** — add unlimited channels from the Settings tab, each with
  its own date/amount matching tolerance. Ships with 7 common channels
  pre-seeded (UB Online, GCash, Maya SO 4.0, Maya FMAX, Maya SO Old,
  DragonPay 4.0, DragonPay FMAX) — delete or rename freely.
- **Flexible CSV import** — paste any CSV export (bank statement or
  back-office report), preview its columns, map them once per channel/side
  (Date, Reference, Amount, etc.), and import. Duplicate rows (same
  channel + date + reference + amount) are automatically skipped on
  re-import.
- **Two-pass matching engine**
  1. **Reference match** — bank reference vs. back-office reference/secondary
     reference (case-insensitive), confirmed by matching amount.
  2. **Amount + date match** — for everything left, pairs rows with equal
     amounts (within tolerance) and the closest date within the channel's
     day-tolerance window.
- **Exceptions queue** — side-by-side unmatched Bank vs. unmatched
  Back-Office tables; manually pair two rows, or mark a row "Ignored" with a
  note (bank fee, timing difference, known write-off, etc.).
- **Dashboard** — totals, match rate, and per-channel breakdown with a
  progress bar and last-run timestamp.
- **Export** — one-click CSV download of a channel's full ledger, or a
  saved snapshot report tab written straight into the data spreadsheet.
- **No manual spreadsheet setup** — the app creates and manages its own
  backing Google Sheet ("Recon App - Data Store") the first time it runs.

## Project structure

```
appsscript.json           Apps Script manifest (V8 runtime, web app config)
Code.gs                   doGet(), include(), bootstrap
SheetService.gs           Data-spreadsheet creation, sheet schemas, helpers
Config.gs                 Channel CRUD + default channel seeding
Importer.gs                CSV preview + mapped, de-duplicated import
ReconciliationEngine.gs   Matching engine, manual match, ignore/reopen
Dashboard.gs              Aggregated stats for the Dashboard tab
ExportService.gs          CSV export + in-sheet report generation
Index.html                Main UI shell (sidebar + page containers)
CSS.html                  Stylesheet (included into Index.html)
JS.html                   Client-side app logic (included into Index.html)
```

## Deploying

You need [`clasp`](https://github.com/google/clasp) (Google's Apps Script
CLI) and a Google account.

```bash
npm install -g @google/clasp
clasp login

# From inside this project folder:
clasp create --type webapp --title "Bank & Back-Office Reconciliation"
# This generates a .clasp.json with your new scriptId - it's gitignored,
# see .clasp.json.example for the shape.

clasp push
clasp deploy --description "Initial release"
```

Then open the deployment URL clasp prints (or run `clasp open --webapp`).
The first page load automatically creates the backing data spreadsheet and
seeds the default channels — nothing else to configure.

### Pushing this repo to GitHub first, then pulling into Apps Script

If you'd rather start from GitHub:

```bash
git init
git add .
git commit -m "Initial commit: bank & back-office reconciliation app"
git remote add origin <your-repo-url>
git push -u origin main

# Later, on any machine:
git clone <your-repo-url>
cd <repo>
clasp create --type webapp --title "Bank & Back-Office Reconciliation"
clasp push
clasp deploy
```

### Access control

`appsscript.json` ships with `"access": "ANYONE"` (anyone with a Google
account and the link) and `"executeAs": "USER_DEPLOYING"` (everyone shares
the same underlying data spreadsheet, owned by whoever deployed it). For a
Google Workspace organization, change `access` to `"DOMAIN"` to restrict the
app to your organization. Redeploy after changing the manifest
(`clasp deploy`).

## Using the app

1. **Settings** — confirm/adjust the channel list and tolerances (date
   window in days, amount tolerance for floating-point/fee differences).
2. **Import Data** — pick a channel and whether you're pasting a *Bank
   Statement* or *Back-Office / Platform* export, paste the CSV, click
   **Preview Columns**, map the fields, then **Import Rows**. Mapping is
   per import — re-paste and re-map any time your export layout changes.
3. **Reconcile** — pick a channel and click **Run Reconciliation**. Safe to
   run repeatedly: already-matched/ignored rows are left untouched, and only
   newly imported rows are considered.
4. **Exceptions** — review what's left unmatched. Select one row from each
   side and click **Match Selected Pair** to confirm a manual match, or
   **Ignore** a row with a short reason. Export the channel's full ledger to
   CSV, or save a timestamped report tab into the data spreadsheet.
5. **Dashboard** — check overall and per-channel match rates at a glance.

## Notes on the data model

Each channel gets two sheets in the data spreadsheet: `BANK - <channel>` and
`BO - <channel>`, both append-only. Every imported row gets a `Source Hash`
so pasting the same export twice is a no-op. Matched pairs share a
`Match Id`; `Match Type` records how they were matched (`Reference Match`,
`Amount + Date Match`, or `Manual Match`) for audit purposes. Nothing is
ever deleted by the reconciliation engine — only status flags change — so
the full history stays intact for audit trails.

## Troubleshooting: no channels showing up

The Settings tab has a **Setup Diagnostics** panel at the top for exactly
this. It shows the data spreadsheet link, how many rows are in the Config
tab, and which Google account the script is running as. If Config rows = 0,
click **"Re-run Setup / Seed Default Channels"** — it's safe to click any
number of times. If diagnostics show an error instead, it's almost always
one of:

- The script hasn't been authorized yet — reopen the web app URL and accept
  the permission prompt.
- In **Deploy → Manage deployments**, "Execute as" is set to "User accessing
  the web app" instead of "Me" — change it to "Me" and create a new
  deployment version so the script always runs with your permissions rather
  than requiring every visitor to authorize their own copy.

